/* eslint-disable prettier/prettier */
export enum StreamTypes {
  CPU = 'CPU',
  MEMORY = 'Memory',
  DEFAULT = 'default',
}
